// Lab 1 – Section A
// Name: Foureiratou Zakari Yaou Idi
// Course: CS313 – Intermediate Computer Programming
// Date: 11th September 2025

/* 
1. To use cin and cout in a program, the program must include the header file iostream.
    1. True
2. Suppose pay is variable of type double. The statement cin >> pay; requires the input of a decimal
number.
    2. True
3. The statement cin >> length; and length >> cin; are equivalent.
    3. False
4. The order in which statements execute in a program is called the flow of control.
    4. True
5. In a one-way selection, if a semicolon is placed after the expression in an if statement, the expression in
the if statement is always true.
    5. True
6. The expression:
( ch >= ’A’ && ch <= ’Z ’ )
evaluates to false if either ch < ’A’ or ch >= ’Z’.
    6. True
7. Suppose the input is 5. The output of the code:
cin >> num;
i f (num > 5 )
cou t << num;
num = 0 ;
e l s e
cou t << "Num i s z e ro " << e n dl ;
is: Num is zero
    7. True
*/
int main() {
    return 0;
}
