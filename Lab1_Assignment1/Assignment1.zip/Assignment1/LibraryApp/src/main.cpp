#include "../include/BookStore.h"

int main() {
    BookStore store;
    store.displayMenu();
    return 0;
}
